package com.harmonyatlas.study;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.CookieManager;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 41;
    private static final int SAVE_BACKUP = 42;
    private WebView web;
    private ValueCallback<Uri[]> selectedFiles;
    private String backupText;
    private String backupName;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(10,16,32));
        getWindow().setNavigationBarColor(Color.rgb(10,16,32));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(10,16,32));
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (selectedFiles != null) selectedFiles.onReceiveValue(null);
                selectedFiles = callback;
                try { startActivityForResult(params.createIntent(), FILE_CHOOSER); return true; }
                catch (Exception ex) { selectedFiles=null; return false; }
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    private class Bridge {
        @JavascriptInterface public void saveBackup(String text, String name) {
            runOnUiThread(() -> {
                backupText = text;
                backupName = (name == null || name.isEmpty()) ? "和声图谱-备份.json" : name;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, backupName);
                startActivityForResult(i, SAVE_BACKUP);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            if (selectedFiles != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int n = data.getClipData().getItemCount(); result = new Uri[n];
                        for (int k=0;k<n;k++) result[k] = data.getClipData().getItemAt(k).getUri();
                    } else if (data.getData() != null) result = new Uri[]{data.getData()};
                }
                selectedFiles.onReceiveValue(result);
                selectedFiles=null;
            }
        } else if (requestCode == SAVE_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null && backupText != null) {
            try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                if (os != null) os.write(backupText.getBytes(StandardCharsets.UTF_8));
            } catch (Exception ignored) { }
            backupText=null;
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){var lb=document.getElementById('lightbox'); if(lb&&!lb.classList.contains('hidden')){lb.classList.add('hidden');return true}var ov=document.getElementById('overlay');if(ov&&!ov.classList.contains('hidden')){ov.classList.add('hidden');return true}var s=document.getElementById('sidebar');if(s&&s.classList.contains('open')){s.classList.remove('open');document.querySelector('.mobile-overlay')?.remove();return true}return false})()", v -> {
            if ("true".equals(v)) return;
            web.evaluateJavascript("(function(){var e=document.querySelector('.backlink');if(e){e.click();return true}return false})()", v2 -> {
                if(!"true".equals(v2)) MainActivity.super.onBackPressed();
            });
        });
    }
    @Override protected void onDestroy() { if(web!=null) web.destroy(); super.onDestroy(); }
}
